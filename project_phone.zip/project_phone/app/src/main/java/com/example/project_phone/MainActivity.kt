package com.example.project_phone

import android.content.Context
import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.app.engine.DatabaseCore
import com.app.engine.StudentRecord
import com.example.project_phone.ui.theme.Project_phoneTheme
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.Charset

enum class AppScreen {
    SIGN_UP,
    LOGIN,
    MAIN_NFC
}

class MainActivity : ComponentActivity(), NfcAdapter.ReaderCallback {

    companion object {
        init { System.loadLibrary("studentdb") }   // must match add_library name in CMakeLists.txt
    }

    private var nfcAdapter: NfcAdapter? = null

    private var statusMessage by mutableStateOf("Click the button and tap an NFC tag.")
    private var isWaitingForTag by mutableStateOf(false)

    private var currentScreen by mutableStateOf(AppScreen.SIGN_UP)

    // Username (email) of the student who is logged in right now
    private var loggedInUsername by mutableStateOf("")

    // The C++ database (created once, reused everywhere)
    private lateinit var db: DatabaseCore
    private val prefs by lazy { getSharedPreferences("app_prefs", Context.MODE_PRIVATE) }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Saving / loading the C++ database ----------
    // The C++ database only lives in memory, so we copy it to SharedPreferences
    // after every change and reload it when the app starts.

    private fun saveDb() {
        val arr = JSONArray()
        for ((id, s) in db.students) {
            arr.put(
                JSONObject()
                    .put("id", id)
                    .put("name", s.name)
                    .put("password", s.password)
                    .put("username", s.username)
                    .put("class", s.mClass)
            )
        }
        prefs.edit().putString("students", arr.toString()).apply()
    }

    private fun loadDb() {
        val arr = JSONArray(prefs.getString("students", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            db.addStudent(
                o.getInt("id"),
                StudentRecord(
                    o.getString("name"),
                    o.getString("password"),
                    o.getString("username"),
                    o.getString("class")
                )
            )
        }
    }

    // ---------- Sign up / login (uses the C++ database) ----------

    // Class and number are stored together in the class field, e.g. "10A|7"
    private fun classLabel(className: String, number: Int) = "${className.trim()}|$number"

    private fun signUp(email: String, password: String, className: String, numberText: String) {
        val number = numberText.toIntOrNull()
        when {
            email.isBlank() || password.isBlank() || className.isBlank() ->
                toast("Please fill in all fields")
            password.length !in 6..10 ->
                toast("Password must be 6-10 characters")
            number == null || number !in 1..30 ->
                toast("Class number must be between 1 and 30")
            db.students.values.any { it.username.equals(email.trim(), true) } ->
                toast("This email is already registered")
            db.students.values.any { it.mClass.equals(classLabel(className, number), true) } ->
                toast("That number is already taken in this class")
            else -> try {
                val newId = (db.students.keys.maxOrNull() ?: 0) + 1
                db.addStudent(
                    newId,
                    StudentRecord(email.trim(), password, email.trim(), classLabel(className, number))
                )
                saveDb()
                toast("Account created successfully!")
                currentScreen = AppScreen.LOGIN
            } catch (e: RuntimeException) {
                toast(e.message ?: "Could not create account")
            }
        }
    }

    private fun login(email: String, password: String) {
        val student = db.students.values.firstOrNull {
            it.username.equals(email.trim(), true) && it.password == password
        }
        if (student != null) {
            loggedInUsername = student.username
            toast("Login successful!")
            currentScreen = AppScreen.MAIN_NFC
        } else {
            toast("Invalid email or password")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        db = DatabaseCore.createDatabase()
        loadDb()
        currentScreen = if (db.students.isNotEmpty()) AppScreen.LOGIN else AppScreen.SIGN_UP

        setContent {
            Project_phoneTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    when (currentScreen) {
                        AppScreen.SIGN_UP -> SignUpScreen(
                            onSignUp = { email, password, cls, number -> signUp(email, password, cls, number) },
                            onNavigateToLogin = { currentScreen = AppScreen.LOGIN },
                            modifier = Modifier.padding(innerPadding)
                        )

                        AppScreen.LOGIN -> LoginScreen(
                            onLogin = { email, password -> login(email, password) },
                            onNavigateToSignUp = { currentScreen = AppScreen.SIGN_UP },
                            modifier = Modifier.padding(innerPadding)
                        )

                        AppScreen.MAIN_NFC -> NfcWriterScreen(
                            statusMessage = statusMessage,
                            isWaitingForTag = isWaitingForTag,
                            hasNfcHardware = nfcAdapter != null,
                            isNfcEnabled = nfcAdapter?.isEnabled == true,
                            onStartWriting = { startNfcWriting() },
                            onOpenSettings = { startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) },
                            onLogout = {
                                loggedInUsername = ""
                                currentScreen = AppScreen.LOGIN
                            },
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }

    private fun startNfcWriting() {
        if (nfcAdapter == null) {
            statusMessage = "Device does not have NFC hardware."
            toast(statusMessage)
            return
        }
        if (nfcAdapter?.isEnabled != true) {
            statusMessage = "NFC is disabled. Please enable NFC in settings."
            toast(statusMessage)
            return
        }

        isWaitingForTag = true
        statusMessage = "Ready! Tap an NFC tag to write..."

        nfcAdapter?.enableReaderMode(
            this,
            this,
            NfcAdapter.FLAG_READER_NFC_A or
                    NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or
                    NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    override fun onTagDiscovered(tag: Tag?) {
        if (tag == null) return
        val success = writeTagToDevice(tag)

        runOnUiThread {
            isWaitingForTag = false
            nfcAdapter?.disableReaderMode(this)
            if (success) {
                statusMessage = "Successfully wrote to NFC tag!"
                Toast.makeText(this, "NFC Tag created successfully!", Toast.LENGTH_LONG).show()
            } else {
                statusMessage = "Failed to write NFC tag."
            }
        }
    }

    /**
     * Reads the logged-in student's username and password from the C++ database
     * and writes them to the NFC tag as JSON: {"username":"...","password":"..."}
     */
    private fun writeTagToDevice(tag: Tag): Boolean {
        try {
            // Get the data from the C++ database
            val student = db.students.values.firstOrNull {
                it.username.equals(loggedInUsername, true)
            }
            if (student == null) {
                runOnUiThread { toast("No logged-in student found") }
                return false
            }

            val json = JSONObject()
                .put("username", student.username)
                .put("password", student.password)
                .toString()

            val mimeBytes = "application/json".toByteArray(Charset.forName("US-ASCII"))
            val dataBytes = json.toByteArray(Charset.forName("UTF-8"))

            val record = NdefRecord(NdefRecord.TNF_MIME_MEDIA, mimeBytes, ByteArray(0), dataBytes)
            val ndefMessage = NdefMessage(arrayOf(record))

            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                try {
                    if (!ndef.isWritable) {
                        runOnUiThread { toast("Tag is read-only") }
                        return false
                    }
                    if (ndef.maxSize < ndefMessage.toByteArray().size) {
                        runOnUiThread { toast("Tag capacity too small") }
                        return false
                    }
                    ndef.writeNdefMessage(ndefMessage)
                    return true
                } finally {
                    ndef.close()
                }
            } else {
                val formatable = NdefFormatable.get(tag)
                if (formatable != null) {
                    formatable.connect()
                    try {
                        formatable.format(ndefMessage)
                        return true
                    } finally {
                        formatable.close()
                    }
                } else {
                    runOnUiThread { toast("Tag does not support NDEF") }
                    return false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            runOnUiThread { Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
            return false
        }
    }

    override fun onPause() {
        super.onPause()
        if (isWaitingForTag) {
            nfcAdapter?.disableReaderMode(this)
            isWaitingForTag = false
        }
    }
}

@Composable
fun SignUpScreen(
    onSignUp: (String, String, String, String) -> Unit,   // email, password, class, number
    onNavigateToLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var className by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Create Account (Sign Up)",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email / Username") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (6-10 characters)") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = className,
            onValueChange = { className = it },
            label = { Text("Class (e.g. 10A)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = number,
            onValueChange = { new -> if (new.length <= 2 && new.all { it.isDigit() }) number = new },
            label = { Text("Number in class (1-30)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
        )

        Button(
            onClick = { onSignUp(email, password, className, number) },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("Sign Up")
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = onNavigateToLogin) {
            Text("Already have an account? Login")
        }
    }
}

@Composable
fun LoginScreen(
    onLogin: (String, String) -> Unit,
    onNavigateToSignUp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Welcome Back (Login)",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email / Username") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        )

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
        )

        Button(
            onClick = { onLogin(email, password) },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("Login")
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = onNavigateToSignUp) {
            Text("Don't have an account? Sign Up")
        }
    }
}

@Composable
fun NfcWriterScreen(
    statusMessage: String,
    isWaitingForTag: Boolean,
    hasNfcHardware: Boolean,
    isNfcEnabled: Boolean,
    onStartWriting: () -> Unit,
    onOpenSettings: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "NFC Tag Creator",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        if (!hasNfcHardware) {
            Text(
                text = "This device does not support NFC.",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        } else if (!isNfcEnabled) {
            Text(
                text = "NFC is currently turned off.",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Button(onClick = onOpenSettings) {
                Text("Open NFC Settings")
            }
        } else {
            Button(
                onClick = onStartWriting,
                enabled = !isWaitingForTag,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text(if (isWaitingForTag) "Tap NFC Tag Now..." else "Create NFC Tag")
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Logout")
            }

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(
                    text = statusMessage,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SignUpPreview() {
    Project_phoneTheme {
        SignUpScreen(onSignUp = { _, _, _, _ -> }, onNavigateToLogin = {})
    }
}

@Preview(showBackground = true)
@Composable
fun LoginPreview() {
    Project_phoneTheme {
        LoginScreen(onLogin = { _, _ -> }, onNavigateToSignUp = {})
    }
}
 