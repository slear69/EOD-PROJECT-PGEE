#include "database_core.hpp"
#include "student_record.hpp"
#include <unordered_map>
#include <stdexcept>
#include <string>

// Include your exact, unmodified classes here (or include the header where they live)
class Student {
    std::string name;
    std::string password;
    std::string username;
    std::string m_class;
public:
    Student(const std::string& name, const std::string& password, const std::string& username, const std::string& m_class)
        : name(name), password(password), username(username), m_class(m_class) {}
    Student() = default;
    const std::string& getName() const { return name; }
    void setName(const std::string& newName) { name = newName; }
    const std::string& getPassword() const { return password; }
    bool setPassword(const std::string& newPassword) { if (newPassword.length() >= 6 && newPassword.length() <= 10) { password = newPassword; return true; } return false; }
    const std::string& getUsername() const { return username; }
    void setUsername(const std::string& newUsername) { username = newUsername; }
    const std::string& getClass() const { return m_class; }
    void setClass(const std::string& newClass) { m_class = newClass; }
};

class Database {
    std::unordered_map<unsigned int, Student> students;
public:
    Database() = default;
    const std::unordered_map<unsigned int, Student>& getStudents() const {
        return students;
    }
    void addStudent(unsigned int id, const Student& student) {
        if (students.find(id) != students.end()) {
            throw std::runtime_error("Student with this ID already exists.");
        }
        students[id] = student;
    }
    void updateStudent(unsigned int id, const Student& student) {
        auto it = students.find(id);
        if (it == students.end()) {
            throw std::runtime_error("Student with this ID does not exist.");
        }
        it->second = student;
    }
    void removeStudent(unsigned int id) {
        auto it = students.find(id);
        if (it == students.end()) {
            throw std::runtime_error("Student with this ID does not exist.");
        }
        students.erase(it);
    }
};

// The adapter class that bridges your Database to Djinni's DatabaseCore interface
class DatabaseCoreImpl : public DatabaseCore {
private:
    Database internal_db;

public:
    std::unordered_map<int32_t, StudentRecord> get_students() override {
        std::unordered_map<int32_t, StudentRecord> result;
        for (const auto& [id, student] : internal_db.getStudents()) {
            StudentRecord rec(
                student.getName(),
                student.getPassword(),
                student.getUsername(),
                student.getClass()
            );
            result[static_cast<int32_t>(id)] = rec;
        }
        return result;
    }

    void add_student(int32_t id, const StudentRecord& student) override {
        Student s(student.name, student.password, student.username, student.m_class);
        internal_db.addStudent(static_cast<unsigned int>(id), s);
    }

    void update_student(int32_t id, const StudentRecord& student) override {
        Student s(student.name, student.password, student.username, student.m_class);
        internal_db.updateStudent(static_cast<unsigned int>(id), s);
    }

    void remove_student(int32_t id) override {
        internal_db.removeStudent(static_cast<unsigned int>(id));
    }
};

// Djinni factory implementation required by database_core.hpp
std::shared_ptr<DatabaseCore> DatabaseCore::create_database() {
    return std::make_shared<DatabaseCoreImpl>();
}
